import React, { Fragment, useState } from 'react'
import { dashboardIcon, accessManagementIcon } from '../helper/svgIcon'
import { Link } from 'react-router-dom'

export default function Sidebar() {
  const sidebarInfo = [
    {
      id: 1,
      name: 'Dashboard',
      icon: dashboardIcon,
      link: '/dashboard',
    },
    {
      id: 2,
      name: 'Access Management',
      icon: dashboardIcon,
      link: '/accessManagement',

      dropdownItem: [
        { name: 'User', icon: dashboardIcon, link: '/accessManagement/user' },
        { name: 'Roles', icon: dashboardIcon, link: '/accessManagement/roles' },
      ],
    },
    {
      id: 3,
      name: 'Widget Management',
      icon: dashboardIcon,
      link: '/dashboard',
      dropdownItem: [
        {
          name: 'Custome Dynamic Html',
          icon: dashboardIcon,
          link: '/customeDynamicHtml',
        },
        { name: 'Dynamic Html', icon: dashboardIcon, link: '/dynamicHtml' },
        { name: 'Static Html', icon: dashboardIcon, link: '/staticHtml' },
        { name: 'Banner', icon: dashboardIcon, link: '/banner' },
        { name: 'Images', icon: dashboardIcon, link: '/images' },
        { name: 'Videos', icon: dashboardIcon, link: '/videos' },
        { name: 'Files', icon: dashboardIcon, link: '/files' },
        { name: 'Forms', icon: dashboardIcon, link: '/forms' },
      ],
    },
    {
      id: 4,
      name: 'Navigation',
      icon: dashboardIcon,
      link: '/navigation',
    },
    {
      id: 5,
      name: 'Pages',
      icon: dashboardIcon,
      link: '/pages',
    },
    {
      id: 6,
      name: 'User Logs',
      icon: dashboardIcon,
      link: '/userLogs',
    },
    {
      id: 7,
      name: 'User Inquiry',
      icon: dashboardIcon,
      link: '/dashboard',
    },
  ]
  const [sideToggleId, setSideToggleId] = useState(0)
  const handeleSibarToggle = (id) => {
    if (id === sideToggleId) {
      setSideToggleId(0)
    } else {
      setSideToggleId(id)
    }
  }
  return (
    <div className="sidebar hide-scrollbar h-[100%]">
      <div className="uniboard-log h-[100%]">
        <aside className="w-full hide-scrollbar overflow-y-scroll h-[100%] bg-[#0072BC] dark:bg-gray-800">
          <div className="px-3 py-4  text-white transition-all duration-300 ">
            <div className="head-container py-6 flex justify-center">
              <h1 className="text-2xl text-white font-bold">UNIBOARD</h1>
            </div>
            <ul className="space-y-2">
              {sidebarInfo.map((item) => (
                <Fragment key={item.id}>
                  {!item.dropdownItem ? (
                    <li>
                      <Link
                        to={item.link}
                        className="flex items-center p-2 text-base text-white font-normal rounded-lg dark:text-white hover:bg-blue-400 dark:hover:bg-gray-700"
                      >
                        {item.icon}
                        <span className="ml-3">{item.name}</span>
                      </Link>
                    </li>
                  ) : (
                    <li>
                      <button
                        type="button"
                        className="flex items-center w-full p-2 text-base font-normal transition-all duration-300 rounded-lg group hover:bg-blue-400 dark:text-white dark:hover:bg-gray-700"
                        onClick={() => handeleSibarToggle(item.id)}
                      >
                        {item.icon}
                        <span
                          className="flex-1 ml-3 text-left whitespace-nowrap"
                          sidebar-toggle-item
                        >
                          {item.name}
                        </span>
                        <svg
                          sidebar-toggle-item
                          className="w-6 h-6"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            fillRule="evenodd"
                            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                            clipRule="evenodd"
                          ></path>
                        </svg>
                      </button>

                      <ul
                        className={
                          sideToggleId === item.id
                            ? 'py-2 space-y-2 '
                            : 'py-2 space-y-2 hidden'
                        }
                      >
                        {item.dropdownItem.map((dropItem, index) => (
                          <li key={index}>
                            <Link
                              to={dropItem.link}
                              className="flex items-center w-full p-2 text-base text-white font-normal transition-all duration-300 rounded-lg group hover:bg-blue-400 dark:text-white dark:hover:bg-gray-700 pl-11"
                            >
                              {dropItem.name}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </li>
                  )}
                </Fragment>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </div>
  )
}
