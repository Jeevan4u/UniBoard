/** @type {import('tailwindcss').Config} */
module.exports = {
  important: true,
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        default: '#243c5a',
      },
      transitionProperty: {
        duration: '300ms',
      },
      keyframes: {
        unfold: {
          '0%': { height: '0%' },
          '100%': { height: '100%' },
        },
        animation: {
          unfold: 'unfold 1s ease-in-out',
        },
      },
    },
  },
  plugins: [],
}
